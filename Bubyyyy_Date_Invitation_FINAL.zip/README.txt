BUBYYYY DATE INVITATION 💗

Open index.html in a browser.

EMAIL:
The Confirm Our Date button submits the selected Date, Time and Place to:
nethmisadeesha2002@gmail.com
using FormSubmit (https://formsubmit.co/).

IMPORTANT:
The first time you use this, FormSubmit may send an activation/confirmation email to the destination address. Open that email and activate the form. After activation, future submissions can arrive automatically.

MUSIC:
The page contains an original soft romantic melody made with the browser's Web Audio API. It starts when Bubyyyy clicks "Open My Invitation", which avoids normal browser autoplay blocking. The music button at the bottom can turn it on/off.

DESIGN:
The UI is intentionally kept close to the supplied pink storyboard: teddy bears, floating hearts, rounded pink cards, September 2026 date picker, time picker, six places, summary, confirmation and confetti.
